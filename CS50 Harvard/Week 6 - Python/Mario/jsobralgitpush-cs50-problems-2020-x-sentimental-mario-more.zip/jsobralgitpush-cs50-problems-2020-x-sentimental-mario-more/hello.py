import cs50

user_name = cs50.get_string("What is your name?\n")
print(f"Hello, {user_name}")