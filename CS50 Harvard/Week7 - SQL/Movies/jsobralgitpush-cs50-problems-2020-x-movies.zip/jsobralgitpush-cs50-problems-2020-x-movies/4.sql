SELECT count(*) FROM ratings WHERE rating = 10;
