SELECT * FROM movies WHERE year = 2008;
